// Tab IDs are stable only within a Chrome session. A new browser session can
// reclaim saved entries by folder and URL, without confusing reused tab IDs.
export class Workspace {
  constructor(entries, session) {
    this.entries = entries;
    this.session = session;
  }

  liveEntry(tabId) {
    return this.entries.find(entry => entry.session === this.session && entry.tabId === tabId);
  }

  removeTab(tabId, windowClosing) {
    const entry = this.liveEntry(tabId);
    if (!entry) return;
    if (windowClosing) {
      delete entry.session;
      delete entry.tabId;
    } else {
      this.entries.splice(this.entries.indexOf(entry), 1);
    }
  }

  observe(tabs, bindings, taskIds) {
    const liveIds = new Set(tabs.map(tab => tab.id));
    this.entries = this.entries.filter(entry => taskIds.has(entry.taskId));
    for (const tab of tabs) {
      const taskId = bindings[tab.groupId];
      const url = tab.pendingUrl || tab.url;
      const entry = this.liveEntry(tab.id);
      if (!taskId || tab.incognito) {
        if (entry) this.removeTab(tab.id, false);
        continue;
      }
      if (!url) continue;
      let target = entry;
      if (!target) {
        target = this.entries.find(item => item.taskId === taskId && item.url === url &&
          (item.session !== this.session || !liveIds.has(item.tabId)));
      }
      if (!target) {
        target = {key: crypto.randomUUID()};
        this.entries.push(target);
      }
      Object.assign(target, {taskId, url, title: tab.title || target.title || url,
        session: this.session, tabId: tab.id});
    }
  }
}
