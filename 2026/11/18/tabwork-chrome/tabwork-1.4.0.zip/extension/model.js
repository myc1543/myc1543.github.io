export const COLORS = ['blue','cyan','green','yellow','orange','red','pink','purple','grey'];
export const DEFAULT_SETTINGS = {mode:'side',duplicates:true,notifications:false,showEmpty:true,askOnStartup:true};
export function urlKey(value) {
  try { const u = new URL(value); return ['http:','https:'].includes(u.protocol) ? u.href : null; } catch { return null; }
}
export function validateLink(value) {
  const url = typeof value?.url === 'string' && urlKey(value.url.trim());
  if (!url || url.length > 8192) throw new Error('请输入有效的 HTTP/HTTPS 网址');
  const parsed = new URL(url);
  if (parsed.username || parsed.password) throw new Error('请移除网址中的账号密码');
  if (value.title != null && typeof value.title !== 'string') throw new Error('链接名称无效');
  const title = value.title?.trim() || parsed.host;
  if (title.length > 250) throw new Error('链接名称最多 250 字');
  return {url, title};
}
function validateLinks(links = []) {
  if (!Array.isArray(links)) throw new Error('链接列表格式无效');
  return Array.from(new Map(links.map(value => {
    const link = validateLink(value);
    return [link.url, link];
  })).values());
}
export function parseDefaults(text) {
  if(typeof text!=='string' || text.length>100000) throw new Error('默认页面内容过长');
  const urls=[];
  text.split(/\r?\n/).forEach((line,i)=>{
    if(!line.trim()) return;
    const key=urlKey(line.trim());
    if(!key) throw new Error(`第 ${i+1} 行需要完整 HTTP/HTTPS 网址`);
    if(new URL(key).username || new URL(key).password) throw new Error('默认网址不能包含账号密码');
    if(!urls.includes(key)) urls.push(key);
  });
  if(urls.length>30) throw new Error('每组最多配置 30 个默认页面');
  return urls;
}
export function validateTask(task) {
  if(!task || typeof task.name!=='string' || !task.name.trim() || task.name.trim().length>40) throw new Error('分组名称需为 1–40 个字符');
  if(typeof task.id!=='string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(task.id)) throw new Error('分组标识无效');
  if(!COLORS.includes(task.color)) throw new Error('分组颜色无效');
  if(!Array.isArray(task.defaults) || task.defaults.some(x=>typeof x!=='string' || /[\r\n]/.test(x))) throw new Error('默认页面格式无效');
  return {id:task.id,name:task.name.trim(),color:task.color,hidden:task.hidden===true,links:validateLinks(task.links),defaults:parseDefaults(task.defaults.join('\n'))};
}
export function exportConfig(state) {
  return {version:1,tasks:state.tasks.map(validateTask),links:validateLinks(state.links),settings:{...DEFAULT_SETTINGS,...state.settings}};
}
export function importConfig(text) {
  if(typeof text!=='string'||text.length>1000000) throw new Error('配置文件不能超过 1 MB');
  let data; try { data=JSON.parse(text); } catch { throw new Error('不是有效的 JSON 配置'); }
  if(data?.version!==1) throw new Error('不支持的配置版本');
  if(!Array.isArray(data.tasks)||data.tasks.length>100) throw new Error('分组列表无效，最多 100 组');
  const tasks=data.tasks.map(validateTask);
  if(new Set(tasks.map(x=>x.id)).size!==tasks.length || new Set(tasks.map(x=>x.name)).size!==tasks.length) throw new Error('分组 ID 或名称重复');
  const s=data.settings ?? {};
  if(s.mode!==undefined && !['side','popup'].includes(s.mode)) throw new Error('展示模式无效');
  for(const k of ['duplicates','notifications','showEmpty','askOnStartup']) if(s[k]!==undefined && typeof s[k]!=='boolean') throw new Error('配置开关必须为布尔值');
  return {version:1,tasks,links:validateLinks(data.links),settings:{mode:s.mode??'side',duplicates:s.duplicates??true,notifications:s.notifications??false,showEmpty:s.showEmpty??true,askOnStartup:s.askOnStartup??true}};
}

// A URL can be a saved link as well as a previously open folder tab.
export function startupCandidates(config, entries, tabs) {
  const seen=new Set();
  for (const tab of tabs) {
    if (!tab.incognito) {
      seen.add(urlKey(tab.url));
      seen.add(urlKey(tab.pendingUrl));
    }
  }
  const pages=[];
  function add(page, taskId) {
    const url=urlKey(page.url);
    if (!url || seen.has(url))return;
    pages.push({url, title:page.title || url, taskId});
  }
  for (const entry of entries)add(entry,entry.taskId);
  for (const task of config.tasks)for (const link of task.links)add(link,task.id);
  for (const link of config.links)add(link,null);
  return pages;
}

export function selectStartupPages(candidates, taskId) {
  const seen = new Set();
  return candidates.filter(page => {
    if (taskId !== undefined && page.taskId !== taskId) return false;
    if (seen.has(page.url)) return false;
    seen.add(page.url);
    return true;
  });
}

export function startupPages(config, entries, tabs, taskId) {
  return selectStartupPages(startupCandidates(config, entries, tabs), taskId);
}
