import {parseDefaults} from './model.js';
const $=s=>document.querySelector(s);
const popup=new URLSearchParams(location.search).get('view')==='popup';
if(popup)document.body.classList.add('popup');
let state,editing=null,showHidden=false,last='',busy=false,toastTimer;
const selectedTabs=new Set();
function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=text;return e;}
function button(text,fn,cls='',title){const b=el('button',cls,text);b.type='button';if(title){b.title=title;b.setAttribute('aria-label',title);}b.addEventListener('click',e=>{e.stopPropagation();run(fn);});return b;}
async function rpc(type,data={}){const response=await chrome.runtime.sendMessage({type,...data});if(!response?.ok)throw new Error(response?.error||'扩展连接失败，请重新打开面板');return response.data;}
function toast(message,error=false){clearTimeout(toastTimer);const t=$('#toast');t.textContent=message;t.classList.toggle('error',error);t.style.display='block';toastTimer=setTimeout(()=>t.style.display='none',error?7000:4000);}
async function run(fn){try{await fn();await refresh(true);}catch(e){toast(e.message,true);}}
async function refresh(force=false){
 if(busy)return;busy=true;
 try{const next=await rpc('snapshot');const key=JSON.stringify(next);state=next;
 if(force||key!==last){last=key;render();}}
 catch(e){toast(e.message,true);}finally{busy=false;}
}
let selectedFolder = null;
const looseId = 'unassigned';
const dragType = 'application/x-tabwork-page';
let organizing = false;

function menuAt(x, y, items) {
  const menu = $('#context-menu');
  menu.replaceChildren(...items);
  menu.hidden = false;
  menu.style.left = Math.max(4, Math.min(x, innerWidth - menu.offsetWidth - 4)) + 'px';
  menu.style.top = Math.max(4, Math.min(y, innerHeight - menu.offsetHeight - 4)) + 'px';
  for (const item of menu.querySelectorAll('button')) item.addEventListener('click', () => { menu.hidden = true; });
}
function addMenu(trigger, build) {
  trigger.addEventListener('contextmenu', event => {
    event.preventDefault();
    menuAt(event.clientX, event.clientY, build());
  });
  trigger.addEventListener('keydown', event => {
    if (event.key === 'ContextMenu' || (event.shiftKey && event.key === 'F10')) {
      event.preventDefault();
      const rect = trigger.getBoundingClientRect();
      menuAt(rect.left, rect.bottom, build());
      $('#context-menu button')?.focus();
    }
  });
}
function movePage(page, taskId) {
  return page.key ? rpc('entry', {action:'move', key:page.key, taskId})
                  : rpc('assign', {tabIds:[page.id], taskId});
}
function pageRow(page, taskId) {
  const row = el('div', 'page');
  const title = page.title || page.url;
  const jump = button(title, () => page.key ? rpc('entry', {action:'open', key:page.key})
                                           : rpc('focus', {tabId:page.id}), 'page-title');
  jump.title = page.url;
  jump.setAttribute('aria-label',title);
  if (page.key && page.liveId === null) row.classList.add('saved');
  if (organizing && (page.liveId ?? page.id) != null) {
    const id = page.liveId ?? page.id;
    const check = el('input');
    check.type = 'checkbox';
    check.checked = selectedTabs.has(id);
    check.setAttribute('aria-label', '选择 ' + title);
    check.onchange = () => {
      if (check.checked) selectedTabs.add(id); else selectedTabs.delete(id);
      $('#batch-move').disabled = !selectedTabs.size;
    };
    row.append(check);
  }
  row.append(jump);
  row.draggable = true;
  row.ondragstart = event => {
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData(dragType, JSON.stringify({key:page.key,id:page.id}));
  };
  addMenu(jump, () => {
    const items = state.tasks.filter(t => t.id !== taskId)
      .map(t => button('移至「' + t.name + '」', () => movePage(page,t.id)));
    if (/^https?:/i.test(page.url)) items.unshift(button('保存为链接', () => openLinkEditor(taskId,page.url,title)));
    if (taskId) items.push(button('移出文件夹', () => movePage(page,null)));
    if (page.liveId != null || page.id != null) items.push(button('关闭此网页', () => rpc('closeTab',{tabId:page.liveId ?? page.id})));
    return items;
  });
  return row;
}
function openLinkEditor(taskId, url='', title='') {
  if (!state) return;
  const picker = $('#link-folder');
  picker.replaceChildren(new Option('工作台根目录',''), ...state.tasks.map(t=>new Option(t.name,t.id)));
  picker.value = taskId || '';
  $('#link-url').value = url;
  $('#link-title').value = title;
  $('#link-error').textContent = '';
  $('#link-editor').showModal();
  $('#link-url').focus();
}
function savedLinkButton(link, taskId) {
  const trigger = button(link.title, () => rpc('openLink',{taskId,url:link.url}), 'saved-link');
  trigger.title = link.url;
  trigger.setAttribute('aria-label',link.title);
  addMenu(trigger, () => [
    button('移除保存的链接', () => confirmAction('移除链接？',link.title,
      () => rpc('deleteLink',{taskId,url:link.url})))
  ]);
  return trigger;
}
function dropTarget(element, taskId) {
  element.ondragover = event => {
    const types = event.dataTransfer.types;
    const moving = types.includes(dragType);
    if (!moving && !(types.includes('text/uri-list') || types.includes('text/plain'))) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = moving ? 'move' : 'copy';
    element.classList.add('drop');
  };
  element.ondragleave = event => {if (!element.contains(event.relatedTarget)) element.classList.remove('drop');};
  element.ondrop = event => {
    element.classList.remove('drop');
    event.preventDefault();
    const data=event.dataTransfer;
    const payload=data.getData(dragType);
    if (payload) run(() => movePage(JSON.parse(payload),taskId));
    else {
      const url=data.getData('text/uri-list').split(/\r?\n/).find(line=>line && !line.startsWith('#')) ||
                data.getData('text/plain').trim();
      if (url) openLinkEditor(taskId,url);
    }
  };
}
function folderRow(task,expanded) {
  const id=task?.id ?? looseId, name=task?.name ?? '未分组';
  const folder=el('div','folder');folder.dataset.task=id;
  const toggle=el('button','task-title');
  toggle.type='button';toggle.setAttribute('aria-expanded',String(expanded));
  toggle.title=name;toggle.setAttribute('aria-label',name);
  toggle.append(el('span','folder-icon'),el('span','folder-name',name));
  toggle.onclick=()=>{
    selectedFolder=selectedFolder===id ? null : id;
    render();
    document.querySelector('[data-task="'+CSS.escape(id)+'"] .task-title')?.focus();
  };
  if(task)addMenu(toggle,()=>folderMenu(task));
  folder.append(toggle);
  dropTarget(folder,task?.id ?? null);
  return folder;
}
function render() {
  if (!state) return;
  const list=$('#content');
  const query=organizing ? $('#search').value.trim().toLowerCase() : '';
  const matches=(item)=>!query || (item.title+' '+item.url).toLowerCase().includes(query);
  list.replaceChildren();
  for(const link of state.links)if(matches(link))list.append(savedLinkButton(link,null));
  const tasks=state.tasks.filter(t=>(showHidden||!t.hidden)&&(state.settings.showEmpty||t.entries.length||t.links.length));
  for(const task of [...tasks,null]){
    const id=task?.id ?? looseId;
    const expanded=Boolean(query)||selectedFolder===id;
    const folder=folderRow(task,expanded);
    if(!expanded){list.append(folder);continue;}
    const links=task?.links || [];
    const saved=new Set(links.map(l=>l.url));
    const pages=(task?.entries ?? state.unassigned).filter(p=>organizing || !saved.has(p.url));
    const matchGroup=query && task?.name.toLowerCase().includes(query);
    const visibleLinks=links.filter(l=>matchGroup||matches(l));
    const visiblePages=pages.filter(p=>matchGroup||matches(p));
    if(query && !matchGroup && !visibleLinks.length && !visiblePages.length)continue;
    const tray=el('div','folder-contents');
    folder.append(tray);
    list.append(folder);
    for(const link of visibleLinks)tray.append(savedLinkButton(link,task.id));
    for(const page of visiblePages)tray.append(pageRow(page,task?.id));
    if(!visiblePages.length && !visibleLinks.length)tray.append(el('p','empty',task?'空文件夹':'没有未分组网页'));
  }
  if(query && !list.childElementCount)list.append(el('p','empty','没有匹配的网页'));
  if(organizing){
    const dest=$('#batch-target'),value=dest.value;
    dest.replaceChildren(...state.tasks.map(t=>new Option(t.name,t.id)));
    if(state.tasks.some(t=>t.id===value))dest.value=value;
    const live=new Set([...state.unassigned,...state.tasks.flatMap(t=>t.tabs)].map(t=>t.id));
    for(const id of selectedTabs)if(!live.has(id))selectedTabs.delete(id);
    $('#batch-move').disabled=!selectedTabs.size||!state.tasks.length;
  }
  renderAlerts();
}
function renderAlerts(){const root=$('#alerts');root.replaceChildren();for(const a of state.alerts){const box=el('div','alert');box.append(el('strong','','发现重复页面'),el('p','',`${a.taskName} · ${a.url}`));const actions=el('div','alert-actions');actions.append(button('跳到已有页面',()=>rpc('resolveAlert',{id:a.id})),button('保留两个',()=>rpc('dismissAlert',{id:a.id})),button('关闭新页并跳转',()=>confirmAction('关闭重复网页？','新页面可能有未保存的输入。确认后关闭新页面并跳到已有页面。',()=>rpc('resolveAlert',{id:a.id,closeNew:true}))));box.append(actions);root.append(box);}}
function folderMenu(task){
 const items=[button('添加链接',()=>openLinkEditor(task.id)),el('hr')];
 items.push(el('div','menu-label','默认页面'));
 if(task.defaults.length){items.push(button('打开全部默认页面',async()=>{const r=await rpc('openDefaults',{taskId:task.id});toast(r.message);}));task.defaults.forEach((url,index)=>items.push(button(url,async()=>{const r=await rpc('openDefaults',{taskId:task.id,index});toast(r.message);},'',url)));}
 items.push(button('设置默认页面…',()=>openEditor(task)),el('hr'));
 items.push(button('编辑文件夹…',()=>openEditor(task)),button(task.hidden?'显示此文件夹':'隐藏此文件夹',()=>rpc('saveTask',{task:{...task,hidden:!task.hidden}})),button('上移',()=>rpc('reorder',{taskId:task.id,direction:-1})),button('下移',()=>rpc('reorder',{taskId:task.id,direction:1})),el('hr'));
 items.push(button('关闭组内全部网页',()=>confirmAction('关闭全部网页？','任务与默认页面会保留。网页中的未保存输入可能丢失。',()=>rpc('closeTask',{taskId:task.id}))),button('删除文件夹，保留打开的网页',()=>confirmAction('删除文件夹？','文件夹及保存的网址将被移除，已打开的网页将解除分组。',()=>rpc('deleteTask',{taskId:task.id})),'danger'));
 return items;
}
function openEditor(task=null){editing=task;$('#editor-title').textContent=task?'编辑文件夹':'新建文件夹';$('#task-name').value=task?.name||'';$('#task-color').value=task?.color||'blue';$('#task-defaults').value=task?.defaults.join('\n')||'';$('#task-hidden').checked=task?.hidden||false;$('#editor-error').textContent='';$('#folder-options').open = !!task;$('#editor').showModal();$('#task-name').focus();}
function confirmAction(title,message,fn){$('#confirm-title').textContent=title;$('#confirm-message').textContent=message;$('#confirm').showModal();$('#confirm-yes').onclick=()=>run(async()=>{await fn();$('#confirm').close();});}
async function setupCollapse(){
  if(popup || !chrome.sidePanel.close || await chrome.tabs.getCurrent())return;
  const control=$('#collapse-panel');
  const align=async()=>{
    const layout=await chrome.sidePanel.getLayout();
    document.body.dataset.dock=layout.side;
  };
  await align();
  control.hidden=false;
  window.addEventListener('focus',()=>align().catch(()=>{}));
  control.onclick=async()=>{
    try{
      const win=await chrome.windows.getCurrent();
      await chrome.sidePanel.close({windowId:win.id});
    }catch(error){toast(error.message,true);}
  };
}
setupCollapse().catch(error=>toast(error.message,true));
$('#more').onclick=()=>{
  const rect=$('#more').getBoundingClientRect();
  const items=[button('新建文件夹',()=>openEditor()),button('设置',openSettings)];
  menuAt(rect.right-230,rect.bottom+2,items);
};
$('#add-link').onclick=()=>openLinkEditor(selectedFolder===looseId?null:selectedFolder);
$('#link-form').onsubmit=async event=>{
  event.preventDefault();
  const submit=event.submitter;submit.disabled=true;
  try {
    const taskId=$('#link-folder').value || null;
    await rpc('saveLink',{taskId,url:$('#link-url').value,title:$('#link-title').value});
    $('#link-editor').close();selectedFolder=taskId;
    await refresh(true);
  } catch(error){$('#link-error').textContent=error.message;}
  finally{submit.disabled=false;}
};
$('#task-form').onsubmit=async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;try{const task={id:editing?.id,name:$('#task-name').value,color:$('#task-color').value,hidden:$('#task-hidden').checked,defaults:parseDefaults($('#task-defaults').value)};await rpc('saveTask',{task});$('#editor').close();await refresh(true);}catch(err){$('#editor-error').textContent=err.message;}finally{b.disabled=false;}};
function openSettings(){if(!state)return;$('#mode').value=state.settings.mode;$('#ask-startup').checked=state.settings.askOnStartup;$('#duplicates').checked=state.settings.duplicates;$('#notifications').checked=state.settings.notifications;$('#show-empty').checked=state.settings.showEmpty;$('#settings').showModal();};
$('#settings-form').onsubmit=e=>{e.preventDefault();run(async()=>{await rpc('settings',{settings:{mode:$('#mode').value,askOnStartup:$('#ask-startup').checked,duplicates:$('#duplicates').checked,notifications:$('#notifications').checked,showEmpty:$('#show-empty').checked}});$('#settings').close();toast('设置已保存，下次点击工具栏图标时生效');});};
$('#open-side').onclick=async()=>{try{const w=await chrome.windows.getCurrent();await chrome.sidePanel.open({windowId:w.id});$('#settings').close();}catch(e){toast(e.message,true);}};
$('#export').onclick=()=>run(async()=>{const config=await rpc('export');const blob=new Blob([JSON.stringify(config,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=el('a');a.href=url;a.download=`tabwork-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);toast('配置已导出');});
$('#import').onclick=()=>$('#import-file').click();
$('#import-file').onchange=e=>run(async()=>{const file=e.target.files[0];e.target.value='';if(!file)return;if(file.size>1000000)throw new Error('配置文件不能超过 1 MB');const r=await rpc('import',{text:await file.text()});toast(r.message);$('#settings').close();});
$('#adopt').onclick=()=>run(async()=>{
 const groups=await chrome.tabGroups.query({});let count=0;
 for(const g of groups){if(state.tasks.some(t=>t.tabs.some(tab=>tab.groupId===g.id)))continue;
   const tabs=await chrome.tabs.query({groupId:g.id});if(!tabs.length)continue;
   let name=g.title||'未命名分组';const names=new Set(state.tasks.map(t=>t.name));while(names.has(name))name+='（导入）';
   const task=await rpc('saveTask',{task:{name,color:g.color,hidden:false,defaults:[]}});await rpc('assign',{taskId:task.id,tabIds:tabs.map(t=>t.id)});state=await rpc('snapshot');count++;
 }toast(`已导入 ${count} 个 Chrome 分组`);$('#settings').close();
});
$('#search').oninput=render;
$('#show-hidden').onchange=e=>{showHidden=e.target.checked;render();};
$('#organize').onclick=()=>{organizing=true;$('#organizer').hidden=false;$('#settings').close();render();$('#search').focus();};
$('#finish').onclick=()=>{organizing=false;selectedTabs.clear();$('#organizer').hidden=true;$('#search').value='';render();};
$('#batch-move').onclick=()=>run(async()=>{await rpc('assign',{taskId:$('#batch-target').value,tabIds:[...selectedTabs]});selectedTabs.clear();});
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>document.getElementById(b.dataset.close).close());
document.addEventListener('click',e=>{if(!e.target.closest('#context-menu,#more'))$('#context-menu').hidden=true;});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){
  if(!$('#context-menu').hidden)$('#context-menu').hidden=true;
  else if(!document.querySelector('dialog[open]')){selectedFolder=null;render();}
}});
await refresh(true);
setInterval(()=>{if(!document.querySelector('dialog[open]')&&$('#context-menu').hidden&&!['INPUT','SELECT','TEXTAREA'].includes(document.activeElement?.tagName))refresh();},1800);
chrome.tabs.onActivated.addListener(()=>{if(!document.querySelector('dialog[open]'))refresh();});
