import {DEFAULT_SETTINGS,startupCandidates,startupPages,validateLink,validateTask,importConfig,exportConfig,urlKey} from './model.js';
import {Workspace} from './workspace.js';
let workspace, savedWorkspace, savedSession, badgeText;
let config, bindings={}, alerts=[], recent={}, queue=Promise.resolve();
const nativeTitle=task=>`▸ ${task.name}`;
function serial(fn){const p=queue.then(fn);queue=p.catch(()=>{});return p;}
async function persist(){await chrome.storage.local.set({config});}
async function persistSession(){
  const data={bindings,alerts,recent};
  const encoded=JSON.stringify(data);
  if(encoded!==savedSession){
    await chrome.storage.session.set(data);
    savedSession=encoded;
  }
}
async function configureAction(){
  await chrome.action.setPopup({popup:config.settings.mode==='popup'?'panel.html?view=popup':''});
  await chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:config.settings.mode==='side'});
}
async function badge(){
  const count=String(alerts.length||'');
  if(count===badgeText)return;
  await chrome.action.setBadgeBackgroundColor({color:'#d27638'});
  await chrome.action.setBadgeText({text:count});
  badgeText=count;
}
function mergeLinks(existing=[],incoming=[]){
  return [...new Map([...existing,...incoming].map(link=>[link.url,link])).values()];
}
async function init(){
  if(config)return;
  const local=await chrome.storage.local.get(['config','entries','restoreVersion']);
  config=local.config?importConfig(JSON.stringify(local.config)):{version:1,tasks:[],links:[],settings:{...DEFAULT_SETTINGS}};
  const session=await chrome.storage.session.get(['bindings','alerts','recent','sessionKey']);
  const sessionKey=session.sessionKey||crypto.randomUUID();
  const version=chrome.runtime.getManifest().version;
  if(!session.sessionKey){
    // An unpacked extension may wake after Chrome has already opened its first window.
    const pending=!!local.config && local.restoreVersion===version;
    await chrome.storage.session.set({sessionKey,startupStatus:pending?'pending':'done'});
  }
  if(local.restoreVersion!==version)await chrome.storage.local.set({restoreVersion:version});
  workspace=new Workspace(local.entries||[],sessionKey);
  bindings=session.bindings||{};alerts=session.alerts||[];recent=session.recent||{};
  await reconcile();await configureAction();await persist();
}
async function reconcile(){
  const groups=await chrome.tabGroups.query({});
  const ids=new Set(groups.map(g=>String(g.id)));
  for(const id of Object.keys(bindings))if(!ids.has(id)||!config.tasks.some(t=>t.id===bindings[id]))delete bindings[id];
  for(const g of groups)if(!bindings[g.id]){
    const matches=config.tasks.filter(t=>nativeTitle(t)===g.title);
    if(matches.length===1)bindings[g.id]=matches[0].id;
  }
  const tabs=await chrome.tabs.query({});const live=new Set(tabs.map(t=>t.id));
  alerts=alerts.filter(a=>live.has(a.newTabId)&&live.has(a.existingTabId)&&tabs.some(t=>t.id===a.newTabId&&urlKey(t.url||t.pendingUrl)===a.url)&&tabs.some(t=>t.id===a.existingTabId&&urlKey(t.url||t.pendingUrl)===a.url));
  for(const id of Object.keys(recent))if(!live.has(Number(id)))delete recent[id];
  workspace.observe(tabs,bindings,new Set(config.tasks.map(task=>task.id)));
  const encoded=JSON.stringify(workspace.entries);
  if(encoded!==savedWorkspace){
    await chrome.storage.local.set({entries:workspace.entries});
    savedWorkspace=encoded;
  }
  await persistSession();await badge();
  return tabs;
}
const getTask=id=>{const t=config.tasks.find(x=>x.id===id);if(!t)throw new Error('任务已不存在，请刷新后重试');return t;};
async function snapshot(){
  const tabs=await reconcile();
  const safeTabs=tabs.filter(t=>!t.incognito && !t.url?.startsWith(chrome.runtime.getURL(''))).map(t=>({id:t.id,windowId:t.windowId,groupId:t.groupId,title:t.title||t.url||'新标签页',url:t.url||t.pendingUrl||'',active:t.active,pinned:t.pinned,taskId:bindings[t.groupId]||null}));
  return {...config,tasks:config.tasks.map(t=>({...t,tabs:safeTabs.filter(tab=>tab.taskId===t.id),entries:workspace.entries.filter(e=>e.taskId===t.id).map(e=>({key:e.key,title:e.title,url:e.url,liveId:e.session===workspace.session&&safeTabs.some(tab=>tab.id===e.tabId&&tab.taskId===t.id)?e.tabId:null}))})),unassigned:safeTabs.filter(t=>!t.taskId),alerts:alerts.map(a=>({...a,taskName:config.tasks.find(t=>t.id===bindings[safeTabs.find(t=>t.id===a.existingTabId)?.groupId])?.name||'未分组'})),tabCount:safeTabs.length};
}
async function focusTab(id){const tab=await chrome.tabs.get(Number(id));await chrome.windows.update(tab.windowId,{focused:true});await chrome.tabs.update(tab.id,{active:true});}
async function assign(taskId,tabIds){
  const task=taskId?getTask(taskId):null;
  const ids=[...new Set(tabIds)];if(!ids.length)throw new Error('请先选择网页');
  const tabs=await Promise.all(ids.map(id=>chrome.tabs.get(Number(id))));
  if(tabs.some(t=>t.incognito))throw new Error('不支持无痕窗口');
  if(!task){await chrome.tabs.ungroup(ids);await reconcile();return;}
  for(const windowId of new Set(tabs.map(t=>t.windowId))){
    const selected=tabs.filter(t=>t.windowId===windowId);
    if(selected.some(t=>t.pinned))throw new Error('固定标签不能加入任务，请先在 Chrome 中取消固定');
    const group=(await chrome.tabGroups.query({windowId})).find(g=>bindings[g.id]===taskId);
    const gid=await chrome.tabs.group(group?{groupId:group.id,tabIds:selected.map(t=>t.id)}:{createProperties:{windowId},tabIds:selected.map(t=>t.id)});
    bindings[gid]=taskId;
    await chrome.tabGroups.update(gid,{title:nativeTitle(task),color:task.color});
  }
  await reconcile();
}
async function openDefaults(taskId,index){
  const t=getTask(taskId);const urls=index===undefined?t.defaults:[t.defaults[index]];
  if(!urls.length||urls.some(x=>!x))throw new Error('请先为任务设置默认页面');
  return openUrls(taskId,urls);
}
async function openUrls(taskId,urls){
  const messages=[];let last;
  for(const url of urls){
    const tabs=await chrome.tabs.query({});const existing=tabs.find(t=>!t.incognito&&urlKey(t.url||t.pendingUrl)===urlKey(url));
    if(existing){
      last=existing.id;
      const other=bindings[existing.groupId];
      if(other&&other!==taskId)messages.push(`已在「${getTask(other).name}」中打开，保留原归属`);
      else if(existing.pinned)messages.push('已复用固定标签，保留固定状态');
      else if(!other && existing.groupId!==-1)messages.push('已在其他 Chrome 分组中打开，保留原归属');
      else if(taskId&&!other)await assign(taskId,[existing.id]);
    }else{
      const win=await chrome.windows.getLastFocused({windowTypes:['normal']});
      if(win.incognito)throw new Error('请先切换到普通窗口');
      const created=await chrome.tabs.create({url,active:false,windowId:win.id});recent[created.id]=urlKey(url);
      if(taskId)await assign(taskId,[created.id]);last=created.id;
    }
  }
  if(last)await focusTab(last);await persistSession();return {message:messages.join('；')||'默认页面已打开，已复用存在的网页'};
}
async function duplicate(tabId){
  if(!config.settings.duplicates)return;
  const tab=await chrome.tabs.get(tabId).catch(()=>null);
  if(!tab||tab.incognito)return;
  const key=urlKey(tab.url||tab.pendingUrl);if(!key||recent[tabId]===key)return;
  recent[tabId]=key;
  const all=await chrome.tabs.query({});
  const same=all.filter(t=>t.id!==tab.id&&!t.incognito&&urlKey(t.url||t.pendingUrl)===key).sort((a,b)=>(b.lastAccessed||0)-(a.lastAccessed||0));
  if(same.length&&!alerts.some(a=>a.url===key&&a.newTabId===tabId)){
    const a={id:crypto.randomUUID(),url:key,title:tab.title||key,newTabId:tabId,existingTabId:same[0].id};
    alerts.unshift(a);alerts=alerts.slice(0,30);
    if(config.settings.notifications){
      const name=config.tasks.find(t=>t.id===bindings[same[0].groupId])?.name||'未分组';
      await chrome.notifications.create(a.id,{type:'basic',iconUrl:'icons/128.png',title:'这个页面已经打开',message:`位于「${name}」。点击通知查看处理选项。`}).catch(()=>{});
    }
  }
  await persistSession();await badge();
}
const restorePage=chrome.runtime.getURL('restore.html');

async function offerStartupRestore(){
  await init();
  if((await chrome.storage.session.get('startupStatus')).startupStatus!=='pending')return;
  const tabs=await reconcile();
  const windows=await chrome.windows.getAll({windowTypes:['normal']});
  const win=windows.find(w=>w.focused&&!w.incognito) || windows.find(w=>!w.incognito);
  if(!win)return; // A background-only launch can precede the first normal window.
  if(config.settings.askOnStartup && startupPages(config,workspace.entries,tabs).length){
    const existing=tabs.find(t=>!t.incognito && (t.url===restorePage || t.pendingUrl===restorePage));
    if(existing)await chrome.tabs.update(existing.id,{active:true});
    else await chrome.tabs.create({windowId:win.id,url:restorePage,active:true});
  }
  await chrome.storage.session.set({startupStatus:'done'});
}

async function restoreSelected(urls,windowId,tabs,taskId){
  const selection=new Set(urls);
  const pages=startupPages(config,workspace.entries,tabs,taskId).filter(p=>selection.has(p.url));
  const failures=[];
  let first;
  for(const page of pages){
    try{
      // Chrome or the user may have opened a page since the prompt appeared.
      const open=await chrome.tabs.query({});
      if(open.some(t=>!t.incognito && (urlKey(t.url)===page.url || urlKey(t.pendingUrl)===page.url)))continue;
      const tab=await chrome.tabs.create({windowId,url:page.url,active:false});
      first ??= tab.id;
      if(page.taskId)await assign(page.taskId,[tab.id]);
    }catch(error){failures.push(page.title+' — '+error.message);}
  }
  return {first,failures};
}

async function handle(m,sender){
  await init();
  const tabs=m.type==='snapshot'?null:await reconcile();
  switch(m.type){
    case 'startupList':
    case 'startupOpen':{
      if(sender.url!==restorePage || sender.tab?.id==null)throw new Error('请在启动询问页中操作');
      if(!config.settings.askOnStartup)return m.type==='startupList'?{pages:[],folders:[]}:{failures:[]};
      if(m.type==='startupList')return {
        pages:startupCandidates(config,workspace.entries,tabs),
        folders:config.tasks.map(({id,name})=>({id,name}))
      };
      return restoreSelected(m.urls,sender.tab.windowId,tabs,m.taskId);
    }
    case 'snapshot':return snapshot();
    case 'entry':{
      const entry=workspace.entries.find(item=>item.key===m.key);
      if(!entry)throw new Error('页面条目已移除');
      const live=entry.session===workspace.session && await chrome.tabs.get(entry.tabId).catch(()=>null);
      if(m.action==='move'){
        if(m.taskId)getTask(m.taskId);
        if(live)await assign(m.taskId,[live.id]);
        else if(m.taskId)entry.taskId=m.taskId;
        else workspace.entries=workspace.entries.filter(item=>item!==entry);
      }else if(m.action==='open'){
        if(live){await focusTab(live.id);return true;}
        if(!urlKey(entry.url)&&entry.url!=='chrome://newtab/')throw new Error('请在 Chrome 中手动打开此特殊网址');
        const created=await chrome.tabs.create({url:entry.url,active:true});
        entry.session=workspace.session;entry.tabId=created.id;
        await assign(entry.taskId,[created.id]);
      }else throw new Error('未知页面操作');
      await reconcile();return true;
    }
    case 'saveLink':
    case 'deleteLink':
    case 'openLink':{
      const owner=m.taskId?getTask(m.taskId):config;
      const link=validateLink(m);
      if(m.type==='openLink'){
        if(!owner.links.some(item=>item.url===link.url))throw new Error('链接已移除');
        return openUrls(m.taskId,[link.url]);
      }
      const next=structuredClone(config);
      const target=m.taskId?next.tasks.find(t=>t.id===m.taskId):next;
      if(m.type==='deleteLink')target.links=target.links.filter(item=>item.url!==link.url);
      else {
        const existing=target.links.find(item=>item.url===link.url);
        if(existing)existing.title=link.title;
        else target.links.push(link);
      }
      if(JSON.stringify(next).length>1000000)throw new Error('工作台配置已满，请先整理链接');
      await chrome.storage.local.set({config:next});
      config=next;
      return true;
    }
    case 'saveTask':{
      const incoming=m.task||{};const task=validateTask({...incoming,links:config.tasks.find(t=>t.id===incoming.id)?.links||[],id:incoming.id||crypto.randomUUID()});
      if(config.tasks.some(t=>t.name===task.name&&t.id!==task.id))throw new Error('已有同名任务，请换一个名称');
      const idx=config.tasks.findIndex(t=>t.id===task.id);
      if(idx<0){if(config.tasks.length>=100)throw new Error('最多创建 100 个任务');config.tasks.push(task);}else config.tasks[idx]=task;
      await persist();
      for(const g of await chrome.tabGroups.query({}))if(bindings[g.id]===task.id)await chrome.tabGroups.update(g.id,{title:nativeTitle(task),color:task.color});
      return task;
    }
    case 'assign':await assign(m.taskId,m.tabIds||[]);return true;
    case 'focus':await focusTab(m.tabId);return true;
    case 'closeTab':{
      await chrome.tabs.remove(Number(m.tabId));
      workspace.removeTab(Number(m.tabId),false);
      await reconcile();return true;
    }
    case 'closeTask':{
      getTask(m.taskId);const ids=(await chrome.tabs.query({})).filter(t=>bindings[t.groupId]===m.taskId).map(t=>t.id);
      if(ids.length)await chrome.tabs.remove(ids);
      for(const id of ids)workspace.removeTab(id,false);
      await reconcile();return true;
    }
    case 'deleteTask':{
      getTask(m.taskId);const tabs=(await chrome.tabs.query({})).filter(t=>bindings[t.groupId]===m.taskId);
      if(tabs.length)await chrome.tabs.ungroup(tabs.map(t=>t.id));
      config.tasks=config.tasks.filter(t=>t.id!==m.taskId);
      for(const k of Object.keys(bindings))if(bindings[k]===m.taskId)delete bindings[k];
      await persist();await persistSession();return true;
    }
    case 'reorder':{
      const i=config.tasks.findIndex(t=>t.id===m.taskId),j=i+(m.direction===-1?-1:1);
      if(i>=0&&j>=0&&j<config.tasks.length)[config.tasks[i],config.tasks[j]]=[config.tasks[j],config.tasks[i]];
      await persist();return true;
    }
    case 'openDefaults':return openDefaults(m.taskId,m.index);
    case 'settings':{
      const next=importConfig(JSON.stringify({...config,settings:{...config.settings,...m.settings}}));config.settings=next.settings;
      if(!config.settings.duplicates){for(const a of alerts)await chrome.notifications.clear(a.id);alerts=[];}
      await persist();await persistSession();await configureAction();await badge();return true;
    }
    case 'dismissAlert':alerts=alerts.filter(a=>a.id!==m.id);await persistSession();await badge();await chrome.notifications.clear(m.id);return true;
    case 'resolveAlert':{
      const a=alerts.find(a=>a.id===m.id);if(!a)throw new Error('提醒已失效');
      const old=await chrome.tabs.get(a.existingTabId);if(urlKey(old.url)!==a.url)throw new Error('原页面已跳转，请重新检查');
      if(m.closeNew){const fresh=await chrome.tabs.get(a.newTabId);if(urlKey(fresh.url)!==a.url)throw new Error('新页面已跳转，未关闭');}
      await focusTab(old.id);if(m.closeNew)await chrome.tabs.remove(a.newTabId);
      alerts=alerts.filter(x=>x.id!==a.id);await persistSession();await badge();await chrome.notifications.clear(a.id);return true;
    }
    case 'export':return exportConfig(config);
    case 'import':{
      const incoming=importConfig(m.text);
      // Merge by task id. Never delete existing containers or browser tabs during import.
      const map=new Map(config.tasks.map(t=>[t.id,t]));for(const t of incoming.tasks){
        const links=mergeLinks(map.get(t.id)?.links,t.links);map.set(t.id,{...t,links});
      }
      const merged=importConfig(JSON.stringify({...incoming,links:mergeLinks(config.links,incoming.links),tasks:[...map.values()]}));
      config=merged;
      if(!config.settings.duplicates){for(const a of alerts)await chrome.notifications.clear(a.id);alerts=[];}
      await persist();await persistSession();await badge();
      for(const g of await chrome.tabGroups.query({})){const task=config.tasks.find(t=>t.id===bindings[g.id]);if(task)await chrome.tabGroups.update(g.id,{title:nativeTitle(task),color:task.color});}
      await configureAction();return {message:'配置已合并；现有任务与网页均保留'};
    }
    default:throw new Error('不支持的操作');
  }
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(sender.id!==chrome.runtime.id)return false;
  serial(()=>handle(message,sender)).then(data=>respond({ok:true,data}),e=>respond({ok:false,error:e.message}));return true;
});
const sync=()=>serial(async()=>{await init();await reconcile();}).catch(console.error);
const checkStartup=()=>serial(offerStartupRestore).catch(console.error);
chrome.runtime.onInstalled.addListener(sync);
chrome.runtime.onStartup.addListener(checkStartup);
chrome.windows.onCreated.addListener(win=>{
  if(win.type==='normal' && !win.incognito)checkStartup();
});
// Consult the session marker on worker wake as well as the browser startup event.
checkStartup();
chrome.tabs.onCreated.addListener(tab=>{serial(async()=>{await init();await duplicate(tab.id);}).catch(console.error);});
chrome.tabs.onUpdated.addListener((id,change)=>{
  if(change.url || change.title || change.groupId!==undefined || change.status==='complete')serial(async()=>{await init();await reconcile();await duplicate(id);}).catch(console.error);
});
chrome.tabs.onRemoved.addListener((id,info)=>serial(async()=>{
  await init();
  workspace.removeTab(id,info.isWindowClosing);
  await reconcile();
}).catch(console.error));
chrome.tabGroups.onRemoved.addListener(sync);
chrome.tabGroups.onCreated.addListener(sync);
chrome.commands.onCommand.addListener((command,tab)=>{if(command==='open-tabwork'&&tab?.windowId)chrome.sidePanel.open({windowId:tab.windowId}).catch(console.error);});
chrome.notifications.onClicked.addListener(()=>{chrome.tabs.create({url:chrome.runtime.getURL('panel.html')});});
