import {selectStartupPages} from './model.js';
const $=id=>document.getElementById(id);
let pages=[];
let candidates=[];
let selectedScope;
let refreshId=0;
let submitting=false;
async function send(type,data={}){
  const result=await chrome.runtime.sendMessage({type,...data});
  if(!result?.ok)throw new Error(result?.error||'连接工作台失败');
  return result.data;
}
async function closePrompt(focusId){
  const tab=await chrome.tabs.getCurrent();
  if(focusId && tab.active)await chrome.tabs.update(focusId,{active:true}).catch(()=>{});
  const others=await chrome.tabs.query({windowId:tab.windowId});
  if(others.length===1)await chrome.tabs.update(tab.id,{url:'chrome://newtab/'});
  else await chrome.tabs.remove(tab.id);
}
async function refresh(){
  const requestId=++refreshId;
  const result=await send('startupList');
  if(requestId!==refreshId)return;
  candidates=result.pages;
  const ids=new Set(candidates.map(page=>page.taskId));
  const folders=[...result.folders,{id:null,name:'工作台根目录'}];
  const available=folders.filter(folder=>ids.has(folder.id) || folder.id===selectedScope);
  const picker=$('scope');
  const options=[new Option('全部保存的页面','all')];
  for(const folder of available)options.push(new Option(folder.name,JSON.stringify(folder.id)));
  if(selectedScope!==undefined && !available.some(folder=>folder.id===selectedScope)){
    options.push(new Option('已移除的文件夹',JSON.stringify(selectedScope)));
  }
  picker.replaceChildren(...options);
  picker.value=selectedScope===undefined?'all':JSON.stringify(selectedScope);
  $('scope-field').hidden=ids.size<2 && selectedScope===undefined;
  render();
}
function render(){
  pages=selectStartupPages(candidates,selectedScope);
  $('summary').textContent=pages.length?'有 '+pages.length+' 个已保存的页面尚未打开。':'已没有待打开的页面。';
  $('open').textContent='打开 '+pages.length+' 个标签页';
  $('open').disabled=!pages.length || submitting;
  $('preview').hidden=!pages.length;
  $('pages').replaceChildren(...pages.map(p=>{
    const item=document.createElement('li');item.textContent=p.title;item.title=p.url;return item;
  }));
}
$('scope').onchange=()=>{
  selectedScope=$('scope').value==='all'?undefined:JSON.parse($('scope').value);
  render();
};
function report(error){$('error').textContent=error.message;}
$('skip').onclick=()=>closePrompt().catch(report);
$('open').onclick=async()=>{
  if(submitting)return;
  submitting=true;$('scope').disabled=true;$('open').disabled=true;$('skip').disabled=true;
  try{
    const result=await send('startupOpen',{urls:pages.map(p=>p.url),taskId:selectedScope});
    if(result.failures.length)throw new Error(result.failures.join('；'));
    await closePrompt(result.first);
  }catch(error){
    submitting=false;$('scope').disabled=false;$('skip').disabled=false;
    report(error);await refresh().catch(report);
  }
};
try {
  await refresh();
  if(!pages.length)await closePrompt();
} catch(error){report(error);}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&!submitting)refresh().catch(report);});
